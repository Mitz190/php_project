<?php
$conn = new mysqli("localhost", "root", "", "f2");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="products.csv"');

$output = fopen("php://output", "w");
fputcsv($output, array("ID", "Product Name", "Price", "Category"));

$result = $conn->query("SELECT * FROM products");
while ($row = $result->fetch_assoc()) {
    fputcsv($output, $row);
}

fclose($output);
$conn->close();
?>
