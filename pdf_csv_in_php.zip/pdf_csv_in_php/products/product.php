<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">

    <div class="container mt-5">
        <h2 class="text-center">Product Management</h2>

        <!-- Product Form -->
        <div class="card p-4 shadow">
            <h4>Add Product</h4>
            <form action="product.php" method="POST">
                <div class="mb-3">
                    <label class="form-label">Product Name</label>
                    <input type="text" class="form-control" name="name" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Price</label>
                    <input type="number" class="form-control" name="price" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Category</label>
                    <input type="text" class="form-control" name="category" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">Add Product</button>
            </form>
        </div>

        <!-- Export Buttons -->
        <div class="mt-4 text-center">
            <a href="download_csv.php" class="btn btn-success">Download CSV</a>
            <a href="download_pdf.php" class="btn btn-danger">Download PDF</a>
        </div>
    </div>

</body>
</html>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $category = $_POST['category'];

    // Database connection
    $conn = new mysqli("localhost", "root", "", "f2");

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert product
    $stmt = $conn->prepare("INSERT INTO products (name, price, category) VALUES (?, ?, ?)");
    $stmt->bind_param("sds", $name, $price, $category);

    if ($stmt->execute()) {
        echo "<script>
                alert('Product added successfully!');
                window.location.href = 'product.php';
              </script>";
    } else {
        echo "Error: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>
